def mostrarDatos(personaModel):
    print("\n===Informacion Personal")
    print(personaModel.mostrarDatos())
    print("\n===")